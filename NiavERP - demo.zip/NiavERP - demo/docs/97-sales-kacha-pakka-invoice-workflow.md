# NiavERP — Kacha → Pakka Invoice Workflow (Sales Side)

> Phase 7. Phase 6 rules fully preserved; no second invoice engine.

## Flow (normative)

`posted Kacha challan(s) (Phase 6 lifecycle/state) → conversion action (eligibility + compatibility per 81, modes per 82–83, DENY rate gate per 84) → Pakka sales invoice posting (same downstream sibling discipline as direct invoices: Accounting + Inventory-invoice-effects + fresh GST determination + audit) → remaining-state roll-up on Kacha lines → derived reads`.

## Preserved without exception

Source/line identity, requested/accepted/remaining quantities, conversion action ID (+ grouping ID for bulk), compatibility fail-closed, rate snapshot + DENY gate + GST recomputation (never typed tax), additive conversion (Kacha retained + linked), full lineage, reversal/correction chains (§101), offline replay convergence, commit-order serialisation.

## Direct vs converted (converge, not fork)

- Direct: commercial facts originate at invoice construction (`94–95`).
- Converted: commercial facts originate at Kacha lines (snapshot) with target-rate statement at conversion (equal unless a future allow-list entry passes all six §84 gates — none exists in Phase 7); GST re-determines on target inputs; quantities validated against remaining, not re-asked.
- Downstream (siblings, payments, returns, audit, reads, races, reversals) identical. One invoice engine (the Engine + consequence owners); two origins.
