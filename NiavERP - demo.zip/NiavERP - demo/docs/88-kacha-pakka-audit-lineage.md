# NiavERP — Kacha → Pakka Audit and Lineage (Conceptual)

> Phase 6. Full chain explainability; references `22`,`71`; adds conversion-specific records.

## Per conversion action (minimum)

Kacha source IDs + numbers + line IDs + requested/accepted quantities + remaining before/after per line + Pakka source/voucher/number + conversion action ID (+ grouping ID for bulk) + rate snapshot vs applied per line + recomputation refs (GST determination ID + version) + actor/role-at-time/device + client/server timestamps + business date + company + reason (rate/adjustment cases) + sibling consequence refs (entry/movement/determination/payment-link IDs) + reversal/correction links + sync/replay identity (attempt IDs, winner refs on dedupe).

## Guarantees

- Kacha creation, posting, cancellation, each conversion, each reversal/correction, each rejection/conflict/dedupe has its audit entry; pre-post UX hints do not.
- Chain traversable both directions: Pakka → conversions → Kacha lines → antecedent movements → sibling money/tax rows → audits; and Kacha → all conversions → all Pakkas → their reversals/corrections.
- Snapshot-vs-applied rate pairs and recomputation refs retained forever; originals never overwritten by later conversions.
