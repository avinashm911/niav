# NiavERP — Phase 6 Decisions (Locked / Deferred / Open)

> Close-out. Phase 0–5 untouched. No code/SQL/UI/deps/integrations.

## LOCKED

1. Kacha controlled + numbered + auditable; never off-book; Kacha≠draft/cancelled/unposted/informal (constitutional reading enforced in `77`,`79`).
2. Series model: company-scoped Kacha/Pakka series, durable identity, server numbers, never recycled (`78`).
3. Three-axis lifecycle preserved (A/B/C split); conversion additive; Pakka invoice ordinary lifecycle + Kacha refs (`79`).
4. Line identity stable; remaining = delivered − converted fold; converted ≤ delivered; remaining ≥ 0; over-conversion structurally rejected with commit-order serialisation (`80`).
5. Eligibility predicate + many→1 compatibility predicate, both fail-closed; same-customer insufficient; deferred splits named not allowed (`81`).
6. Exactly Phase 1 shapes (1→1, 1→many partial, many→1, bulk-as-grouping); per-action durable record with idempotency + audit; no fifth shape (`82`,`83`).
7. Rate-edit DENY default with six-gate future-allowance shape; no allow-list locked; quantity untouched by rate edits; recomputation owned by GST; offline previews non-binding (`84`).
8. Consequence participation declared (LOCKED global correction): challan posts the single delivery OUT and no revenue/receivable/cash/liability; conversion posts invoice accounting/GST siblings atomically with NO further inventory movement; payments none at conversion (`85`).
9. Reversal (compensating + remaining recalc via lineage) + correction (reversal + replacement, shared ID) additive; convertibility restored only via engine transitions (`86`).
10. Offline queue-then-validate + idempotent convergence + already-consumed/stale/auth paths; no silent merges (`87`); concurrency serialisation incl. canonical 40+70-vs-100 with fail-closed remainder (`87`).
11. Full conversion audit/lineage both directions with snapshot-vs-applied + recomputation refs retained (`88`).
12. 30 invariants + 61-case matrix as Phase 7 entry gate (`89`,`90`).

## DEFERRED (explicit)

Invoice/sales workflows + purchase workflows; statutory delivery-challan special cases beyond architecture support; rate-edit allow-list entries; detailed accounting/GST consequence bindings (accounts, tax timing matrix beyond lineage preservation); payment allocation; reports/reconciliation; Tally/BUSY; schema/SQL/APIs; UI; roles implementation; serial/batch/expiry interplay; multi-currency; Bill-to/Ship-to + SEZ + RCM-mixed-batch refinements.

## OPEN (risks carried)

- Target-side tax-timing matrix (challan-movement vs invoice-liability interaction) needs Phase 7 policy surfacing without redefining conversion lineage.
- Rate-allowance pressure from shops (“just fix the price”) — DENY holds until a narrow, evidenced, constitution-compatible entry is proposed and separately approved.
- Multi-source UX complexity (partial consumption across many challans into one invoice) needs Phase 7/10 actionable rejection/refresh design so fail-closed is usable, not obstructive.

## Phase 7 prerequisites

Conversion spine (numbered Kacha + line identity + derived remaining + compatibility-gated actions + DENY rate gate + atomic Engine posting + lineage/audit/idempotency) with money/quantity/tax unowned. Phase 7 may define sales invoice workflows (direct + converted), return linkage, and sales-side payment hooks on top — without redefining conversion, remaining, numbering, or cross-domain ownership.
