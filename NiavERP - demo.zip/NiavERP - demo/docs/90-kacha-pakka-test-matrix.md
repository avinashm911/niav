# NiavERP — Kacha → Pakka Test Matrix (No Code)

> Phase 6. Each case: Setup / Action / Expected / Invariants (→ `89`) / Deterministic? All deterministic except race-order notes (history-deterministic).

## FOUNDATION (6)

1. Create+number+post Kacha. Valid challan → numbered posted Kacha + movement (per §85) + audit. Guards: 1,3. Det: yes.
2. Kacha visible/auditable pre-conversion (not hidable). Guards: 2,29. Det: yes.
3. Cancel before post → no consequences, ID retired. Guards: 24. Det: yes.
4. Cancelled number never reused. Guards: 4. Det: yes.
5. Company scope enforced (cross-company refs rejected). Guards: 30. Det: yes.
6. Lifecycle vs conversion-state split (posted + not_converted simultaneously representable). Guards: 25,26. Det: yes.

## LINE QUANTITY (6)

7. Full quantity tracked (delivered = converted → fully). Guards: 8,9. Det: yes.
8. Partial leaves remainder (100→40, remaining 60, state partial). Guards: 8,11. Det: yes.
9. Multiple partials complete (40+60 → fully, lineage both actions). Guards: 8,11. Det: yes.
10. Exact completion boundary (request == remaining posts; +1 over fails). Guards: 9,10. Det: yes.
11. Over-conversion rejected (request > remaining → fail closed, nothing consumed). Guards: 9,10. Det: yes.
12. Negative remainder impossible (any path). Guards: 10. Det: yes.

## ONE→ONE (3)

13. 1 Kacha → 1 Pakka full with complete ref set + audit. Guards: 5,6,7. Det: yes.
14. Kacha retained + linked post-conversion (queryable both directions). Guards: 5,6,29. Det: yes.
15. Duplicate action replay converges (same action ID → originals). Guards: 20. Det: yes.

## ONE→MANY (4)

16. First partial posts (state partial). Guards: 8,11. Det: yes.
17. Second partial completes. Guards: 8. Det: yes.
18. Completion flips state fully with full history. Guards: 8,26. Det: yes.
19. Duplicate partial replay converges. Guards: 20. Det: yes.

## MANY→ONE (5)

20. Compatible set posts one Pakka with union refs. Guards: 6,7,12. Det: yes.
21. Incompatible set (cross-party / mixed jurisdiction structure / unit-mismatch) fails closed whole action. Guards: 12,13. Det: yes.
22. Same-customer-but-incompatible still rejected. Guards: 12,13. Det: yes.
23. Partial consumption per source inside one Pakka (one source completes, another stays partial). Guards: 8,11. Det: yes.
24. Union lineage traversable (Pakka → all sources → all lines). Guards: 6,29. Det: yes.

## RATE EDIT (7)

25. Default denial (snapshot≠target without allow-list → rejected). Guards: 14. Det: yes.
26. Unauthorized edit rejected (even with reason). Guards: 14,27. Det: yes.
27. Missing reason rejected (even by authorized actor). Guards: 15. Det: yes.
28. Failed recomputation fails action closed (nothing consumed). Guards: 15,16. Det: yes.
29. Permitted edit path exists only via future allow-list (no passing case exists in Phase 6 — test asserts denial surface + six-gate checklist presence). Guards: 14,15. Det: yes.
30. Snapshot preserved + target statement audited on any future allowance (structural assertion). Guards: 15,29. Det: yes.
31. GST recomputation boundary (Kacha/Pakka computes nothing; GST determination ref present). Guards: 16. Det: yes.

## REVERSAL (4)

32. Conversion reversal compensates + restores remaining via lineage. Guards: 22. Det: yes.
33. Duplicate reversal rejected. Guards: 22. Det: yes.
34. Reversal race (reverse vs second convert) orders deterministically; loser fails/redirects. Guards: 21. Det: history-deterministic.
35. Originals retained post-reversal (Kacha+Pakka+action queryable). Guards: 22,29. Det: yes.

## CORRECTION (5)

36. Correction = reversal + replacement, shared ID, originals retained. Guards: 23. Det: yes.
37. Replacement carries full ref set + rate statement. Guards: 6,15. Det: yes.
38. Failed replacement fails per action policy with lineage equivalence. Guards: 23. Det: yes.
39. Duplicate correction converges/rejects deterministically. Guards: 20,23. Det: yes.
40. Convertibility after correction reflects net lineage only. Guards: 8,26. Det: yes.

## OFFLINE (8)

41. Offline Kacha posts once on sync. Guards: 20. Det: yes.
42. Offline conversion posts once with then-current validation. Guards: 19,20. Det: yes.
43. Delayed sync with consumed-remaining elsewhere → deterministic reject + refresh. Guards: 9,21. Det: yes.
44. Duplicate replay converges (ack loss / double-tap / second device same ID). Guards: 20. Det: yes.
45. Source consumed elsewhere before arrival → reject, no partial. Guards: 9. Det: yes.
46. Stale GST config at arrival → re-determine or reject; provisional discarded. Guards: 16. Det: yes.
47. Stock changed while offline → re-validate (DENY-negatives). Guards: 18. Det: yes.
48. Auth changed while offline → reject at commit. Guards: 27. Det: yes.

## CONCURRENCY (6)

49. 40 + 70 vs 100 → first consumes, second fails closed (never 110). Guards: 9,10,21. Det: history-deterministic.
50. Same action ID race → one conversion, loser converges. Guards: 20. Det: history-deterministic.
51. Same-line race → serialised, second sees updated remaining. Guards: 21. Det: history-deterministic.
52. Reversal-vs-conversion race → deterministic order; conversion on reversed line fails eligibility. Guards: 21,22. Det: history-deterministic.
53. Correction-vs-conversion race → deterministic order with lineage equivalence. Guards: 21,23. Det: history-deterministic.
54. Multi-source race (two actions sharing a source line) → one wins per line; other fails or scopes to remaining per policy surface. Guards: 12,21. Det: history-deterministic.

## BOUNDARIES (7)

55. Accounting ownership (conversion writes no legs). Guards: 17. Det: yes.
56. Inventory ownership (conversion writes no movements). Guards: 18. Det: yes.
57. GST ownership (conversion computes no tax). Guards: 16. Det: yes.
58. Engine orchestration (atomic siblings-or-failure). Guards: 19. Det: yes.
59. No UI truth (server re-validates all conversion inputs). Guards: 27. Det: yes.
60. No Tally/BUSY logic in conversion paths. Guards: scope. Det: yes.
61. No evasion path (no suppressible lines/flags, no hidable Kacha, no editable history). Guards: 2,28,29. Det: yes.
