# NiavERP — Sales Document and Invoice Model (Conceptual)

> Phase 7. Identity + lifecycle reuse. No competing state machine. No columns.

## Identity

- Sales document identity = source durable ID + voucher identity + invoice number (unique per company-series, server-assigned at post). Company scope mandatory. Business date (commercial) + client stamp (device creation) + server stamp (commit) all retained, never conflated. Party, registration-context refs, sales/stock location refs, currency (single INR V1), lines, totals (commercial roll-ups as captured, not computed truth), tax-summary refs (pointers to GST determination, not copies), payment/application refs (links, not balances), full source lineage (incl. Kacha ancestors + conversion action IDs where converted).

## Lifecycle (Phase 5 axes only)

- Axis A: `draft → pending_sync → posted` + overlays `cancelled` (pre-post only, zero consequences), `reversed`/`corrected` (post-post via new chains). Backward moves rejected; posted immutable.
- Explicitly NOT lifecycle: payment state (`unpaid/partial/paid/advance-held` = derived application fold), return state (`returnable/partially-returned/fully-returned` = derived return-linkage fold), correction lineage (Axis-C links). Four independent views; collapsing them into one status field is forbidden.
