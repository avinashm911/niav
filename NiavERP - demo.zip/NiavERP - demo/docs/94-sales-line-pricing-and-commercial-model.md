# NiavERP — Sales Line Pricing and Commercial Model (Conceptual)

> Phase 7. Commercial facts captured; computation owned downstream. No statutory invention, no rounding-rule invention.

## Line facts (captured by Sales, not computed as truth)

Item ref + item snapshot (name/unit-at-time for readability; identity is Item ID) + quantity (>0 exact) + unit (resolves to stock unit per Phase 3 invariant; no silent ratios) + unit price (as agreed/recorded) + price snapshot (frozen at intent) + line amount (qty × price as captured arithmetic, exact decimal) + discount adjusters (amount/rate as recorded inputs with level — line vs bill — labelled, not interpreted) + additional charges hooks (labelled inputs) + commercial-adjustment refs + tax-exclusive/tax-inclusive representation flag (how the price was quoted; GST interprets, Sales never converts silently) + final line amount as captured → passed as GST taxable-value *inputs*.

## Ownership split (locked)

- Sales owns: completeness + stability of captured commercial inputs (what was agreed, in what representation, with which adjusters labelled).
- GST owns: taxable-value determination, rate resolution, component math, rounding application (per `52` trace).
- Accounting owns: revenue/receivable leg semantics on the determined values.
- Inventory owns: quantity effect (qty/unit/location only; prices invisible to stock truth).
- Discount/rounding ambiguity rule: any unsettled policy (level ordering, inclusive↔exclusive conversion, round-off placement) is an explicit deferred commercial-policy item (`105§C`); determination requires explicit inputs or fails closed as ambiguous — Sales never defaults, never double-interprets, never hides an adjuster inside quantity or price.
