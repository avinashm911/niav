# NiavERP — Partial and Multi-Source Conversion Detail (Conceptual)

> Phase 6. Additive, auditable splits and merges. Illustrations are concepts, not rules.

## Partial (one line, many actions)

- Line delivered 100 → action A converts 40 (remaining 60, state partial) → action B converts 60 (remaining 0, state full). Each action validates remaining-at-commit, posts atomically with its Pakka (or Pakka-line share), links refs, audits. Over-request (e.g., 70 when 60 remain) fails closed; no negative remainder; no line-identity split; no source disappearance.
- Guards: converted ≤ delivered; remaining ≥ 0; double-spend across concurrent partials serialised (40+70 vs 100 → second fails with refresh path, never 110).

## Multi-source (many lines/sources, one Pakka)

- Each source contributes fully or partially (its own remaining check); the Pakka carries the union of (source, line, qty) refs; remaining updates fan out per source line; challan states roll up independently (one source may complete while another stays partial under the same invoice).
- Compatibility per §81 gates the whole action; partial consumption allowed per source but the action itself is all-or-none (no half-invoice with half-consumed sources).
