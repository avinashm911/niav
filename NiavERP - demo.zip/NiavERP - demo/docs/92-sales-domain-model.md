# NiavERP — Sales Domain Model (Conceptual)

> Phase 7. Bounded commercial workflow over approved engines. No code/SQL/UI/rates/integrations.
> Authority: Phase 0–6 gated. Sales orchestrates intent; owns no consequence semantics.

## Purpose / scope / non-scope

- Purpose: define the sell-side commercial intent (who buys what, where, at what commercial facts) and route it through Transaction Engine → Accounting/Inventory/GST/Payments → Audit → derived reads, for both direct and Kacha→Pakka-origin invoices, plus returns/corrections.
- Scope: intent, document/line commercial facts, party/registration/location context capture, direct + converted invoice workflows, consequence orchestration contract, payment/receivable linkage, returns, cancel/reverse/correct, numbering/period/concurrency, offline/sync, audit/reporting hooks, invariants/tests/decisions.
- Non-scope: accounting legs, stock math, tax classification/calculation, payment allocation algorithms, collection workflows, gateway integration, reports implementation, filing, Tally/BUSY, UX screens.

## Terminology (sales-local; defers to Phase 1 where overlapping)

Sales intent (commercial ask) → Sales document/Invoice (numbered business paper) → Invoice line (per-item commercial facts) → Pricing snapshot (values-as-recorded) → Receivable (derived outstanding view) → Return (additive linked intent). Direct Sale = invoice with no Kacha ancestors. Kacha/Pakka-origin Sale = invoice with Kacha ancestors via conversion action(s). Both converge on identical downstream consequence owners.

## Ownership / identity / lifecycle / mutability / lineage / boundaries / dependencies

- Owner: Sales owns intent capture + commercial-fact completeness + workflow sequencing only.
- Identity: sales source durable ID (1↔1 transaction/voucher per Phase 5); line intent IDs stable within source; Kacha refs carried verbatim where converted.
- Lifecycle: Phase 5 axes only (A draft→pending_sync→posted + overlays; B conversion-state on Kacha side; C links). Payment state, return state derived, never lifecycle.
- Relationships: Sales → Party/Item/Location/Series/Registration reads; Sales → Engine (submit); Engine → Accounting/Inventory/GST/Payments (consequences); all → Audit; Reads ← consequences.
- Mutable: draft/pending_sync intent only. Posted immutable; change via return/reversal/correction chains.
- Lineage: source → (Kacha ancestors) → transaction/voucher → siblings → applications → returns/corrections → audit → sync.
- Boundaries: Accounting owns money; Inventory owns quantities; GST owns tax; Payments owns payment facts; Receivables owns outstanding derivation; Engine owns orchestration; Kacha/Pakka owns conversion policy. Sales duplicates none.
- Dependency graph (acyclic business level): Masters/Series/Registrations → Sales intent → Engine → {Accounting, Inventory, GST, Payments} → Audit → Reads. Kacha/Pakka → Sales (converted path only). No back-edges: consequence domains never command Sales or each other.
