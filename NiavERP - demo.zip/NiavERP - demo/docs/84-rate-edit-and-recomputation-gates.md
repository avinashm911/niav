# NiavERP — Rate-Edit and Recomputation Gates (Conceptual, Default DENY)

> Phase 6. No allow-list locked (insufficient statutory/commercial evidence at design scope); fail-closed. Any future permission needs a new explicit decision satisfying all gates below.

## Default (locked): RATE EDIT = DENY

Any target rate differing from the Kacha line rate snapshot is rejected at conversion validation unless a future allow-list entry expressly permits that case. Phase 6 defines the gate shape, not the entries.

## Gate shape (all six required for any future permitted case)

1. **Permitted case:** named allow-list entry (e.g., to-be-defined corrected-rate-before-invoicing classes — NOT locked here).
2. **Authorized actor:** conversion-rate permission distinct from plain conversion permission (roles → Phase 16).
3. **Explicit reason:** recorded per line (not per action alone) + audit.
4. **Deterministic recomputation:** target values + GST re-determination recomputed by GST engine from target inputs (never typed amounts); inventory quantity unchanged by rate edits (rates affect value/tax, never quantities).
5. **Complete audit:** snapshot vs target per line, actor, reason, recomputation refs (determination ID + version), action ID.
6. **Source preservation:** Kacha snapshot immutable; target carries both snapshot ref and applied rate; originals queryable forever.

## Failure semantics

Recomputation failure (unresolvable classification, missing config, inconsistent totals) fails the conversion action closed with category per `70` (GST/accounting sibling veto class); no partial Pakka, no consumed remaining, no silent fallback to snapshot rate. Offline rate-edit attempts are rejected at post-time re-validation (provisional preview only, labelled, never binding).
