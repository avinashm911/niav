# NiavERP — Sales Party, Registration and Context (Conceptual)

> Phase 7. Context capture + validation; GST rules stay in Phase 4. Bill-to/Ship-to stays deferred.

## Capture (per invoice)

Customer Party (role customer; single Party identity per `20`) + billing context + seller/company registration context (at business date) + customer registration status context (registered/unregistered/special-flag as input) + place-of-supply inputs (supply-side + recipient-side locations/registrations per `50`, never a copied address) + sales location (commercial occurrence) + warehouse/stock location (quantity effect site; may equal sales location) + currency (INR V1).

## Bill-to / Ship-to boundary

Phase 6 deferred Bill-to/Ship-to splits; Phase 7 keeps them deferred (no split-address determination logic, no Siplit-rule invention). Where counterparties volunteer distinct bill/ship addresses, Sales stores them as labelled evidence attributes only; jurisdiction determination still follows `50–51` inputs. Split-driven place-of-supply refinements are explicit deferred items (`105§C`).

## Validation (Sales-contributed preconditions; Engine + domains decide)

Missing customer → reject (except tightly-scoped counter-sale anonymous path only if a later UX/policy decision explicitly creates it — none in Phase 7; default require party). Invalid role (supplier-only party used as customer without customer role) → reject. Missing required GST context (registration/jurisdiction inputs incomplete for a taxable-class claim) → reject as ambiguous (never silent-tax). Ambiguous registration (multiple/overlapping/expired coverage) → reject with refresh path. Unavailable sales/stock location (unknown/retired/cross-company) → reject. All rejections categorised per `70` with owner-understandable reasons; GST rule content itself never invented here.
