# NiavERP — Kacha → Pakka Invariants (Locked)

> Phase 6. Must-hold statements. Each maps to `90` matrix cases.

1. Kacha is a first-class controlled document (numbered, posted, auditable).
2. Kacha is never off-book by definition; no interpretation path treats it as unrecorded/hidable.
3. Every Kacha document is numbered (series-scoped, server-assigned).
4. Numbers never recycled (cancelled/converted/reversed numbers stay retired with history).
5. Conversion never deletes the Kacha source (all patterns preserve it).
6. Every Pakka converted from Kacha retains the full (source, line, qty) ref set.
7. Every conversion is an explicit durable action with stable ID + audit.
8. Remaining is derived (`delivered − converted` fold), never stored truth, never directly editable.
9. Converted never exceeds eligible (delivered minus reversed) per line.
10. Remaining never negative.
11. Partial conversion preserves source line identity (no splits into new identities).
12. Multi-source conversion requires full compatibility (§81); partial compatibility never suffices.
13. Incompatible sources never merge (fail closed, no silent union).
14. Rate edits default DENY; any allowance needs a future explicit allow-list entry.
15. Any permitted rate edit carries case + actor + reason + recomputation + audit + preserved snapshot.
16. Tax (re)calculation owned solely by GST; Kacha/Pakka never computes tax.
17. Money consequences owned solely by Accounting; conversion never writes legs.
18. Quantity consequences owned solely by Inventory; conversion never writes movements.
19. Every conversion posts atomically through the Engine (siblings or clean failure).
20. Conversion replay idempotent (same action ID → originals).
21. Concurrent conversions never over-consume (commit-order serialisation + fail-closed remainder).
22. Reversal preserves conversion history (compensating chain + links + remaining recalc).
23. Correction preserves history (reversal + replacement, shared ID, overlays).
24. Pre-post Kacha cancel creates zero posted consequences.
25. Lifecycle (A), conversion state (B), correction links (C) never collapsed into one field.
26. Conversion state derived from authoritative lineage only.
27. Every conversion passes authorization + validation (no bypass, no UI truth).
28. No conversion path creates hidden/off-books activity (no suppressible lines/flags/views).
29. Audit/lineage complete and undeletable across the Kacha→Pakka graph.
30. Single-company scope per conversion; cross-company refs rejected.
