# NiavERP — Direct Sales Invoice Workflow (Conceptual)

> Phase 7. Intent → Engine → siblings → audit → reads. Sales preconditions only; Phase 5 sequencing reused.

## Flow (normative)

`sales intent (party/lines/location/price-context) → source durable ID + line IDs → invoice construction (commercial completeness per 93–95) → Sales validation (company, auth-grant, party/role, item stockability, qty/unit/price well-formedness, location availability-hint only, period/series eligibility-hint, idempotency novelty, GST-input completeness hint, payment-input shape) → Engine (14-stage authoritative validation per 65) → atomic post (Accounting + Inventory + GST + Payment-hooks where declared + audit) → derived reads (receivable/registers/summaries labelled pending vs posted)`.

## Cash vs credit (locked distinction, no bypass)

- Both post identically through the Engine with identical sibling discipline. Difference is only payment linkage at/after posting: cash sale carries payment intent(s) in the same business action (same source action ID, payment posted as sibling + application links per `99`); credit sale posts with zero applications (receivable outstanding = full, derived). Cash never bypasses Engine, never nets inside the invoice, never fabricates settlement. `paid/unpaid` is derived application state, never an editable field, never a lifecycle state.
