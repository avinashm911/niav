# NiavERP — Kacha → Pakka Offline and Concurrency (Conceptual)

> Phase 6. Server-authoritative remaining; idempotent actions; no silent merges. No SQLite/sync implementation.

- **Offline Kacha creation:** durable ID + client stamp queued; server assigns number/period at post; estimates only offline.
- **Offline conversion (single/partial/multi-source):** queued conversion action(s) with full ref sets + snapshot-vs-target statement; validated at arrival against then-current remaining/period/grants/config. Stale anything → deterministic reject + refresh path.
- **Duplicate replay (retry, ack loss, double-tap, second device same action ID):** converges to original conversion + Pakka refs + dedupe audit; never second Pakka, never double consumption.
- **Already-consumed-elsewhere:** second action requesting consumed remaining fails over-conversion rules with the authoritative remaining shown; loser refreshes (split smaller, pick other sources, reverse-then-reconvert via policy).
- **Canonical race (40 + 70 vs 100):** commit-order serialisation; first valid consumes, second fails closed (no 110, no partial consumption of the failed action). Same-action races converge; line races serialise per line; reversal-vs-conversion and correction-vs-conversion races order deterministically (a conversion landing on a line whose source just reversed fails eligibility; a reversal landing on a just-converted line reverses the conversion chain per §86 rather than editing it).
- **Rate-edit offline:** provisional preview only; authoritative DENY-or-gate evaluation at server commit; stale-config supersede per `59` (no silent rate carry-over).
- **Stock/config/auth changed while offline:** re-validated (DENY-negatives, config coverage, grant-at-time); rejections actionable, never auto-adjusted.
