# NiavERP — Kacha → Pakka Consequences (Conceptual Participation)

> Phase 6. Kacha/Pakka declares conversion semantics; domains own all effects via Engine fan-out. No entries/movements/tax computed here.

## Participation per event (declared, not assumed)

- **Kacha creation/posting (challan — LOCKED global correction):** THE single physical inventory OUT movement per line (type `delivery`) + Audit. Accounting: none (no revenue, no receivable, no cash/bank, no COGS). GST: no invoice liability (liability arises on invoice determination; statutory-trigger refinements reference the GST engine, never duplicated here). Payments/Receivables: none.
- **Kacha cancellation (pre-post):** no consequences; audit only. Post-post “cancel” is reversal, not voiding.
- **Conversion → Pakka (full/partial/many-to-one — LOCKED global correction):** new Pakka invoice posting with Accounting (revenue/receivable legs per Phase 2 policy surface), Inventory: NONE — no second movement (the delivery already moved at Kacha time; enforced by `trg_no_double_issue`), GST (fresh determination + lines on target inputs), Audit (conversion action + sibling refs). Payments: none at conversion (applications append later per Phase 9 policy surface).
- **Conversion reversal/correction:** compensating siblings per domain owners + remaining-state recalculation (§86); Kacha and Pakka originals retained; convertibility restored only via engine-mediated transitions.
- Every event above executes as an Engine atomic posting (or linked postings for reversal+replacement) with idempotency + numbering + period/grant validation. Kacha/Pakka never writes ledger rows, movements, or tax lines directly.
